package tech.soulike.yunzhan.cloudexhibition.util

/**
 * Created by thunder on 18-3-6.
 */
 object StringUtil {
 const val START_PICTURE = "start_picture"
 const val END_PICTURE = "end_picture"
 const val CURRENT_PICTURE = "current_picture"
 const val URL = "http://47.94.234.136/server/android/"
 var CHECK_RESULT = "check_result"
 var PACKAGE_NAME = "tech.soulike.yunzhan.cloudexhibition"
}