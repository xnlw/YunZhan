package tech.soulike.yunzhan.cloudexhibition.base

import org.litepal.crud.DataSupport

/**
 * Created by thunder on 18-3-7.
 *
 */
class ResourceData :DataSupport(){
    lateinit var adName: String
    var type = 0
    lateinit var adMd5: String
    lateinit var adUrl: String
    var adId:Int = 0
    var adTime:Int = 0
    lateinit var qrCodeUrl:String
    lateinit var qrCodePosition:String
}